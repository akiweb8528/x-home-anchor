"use strict";
(() => {
  // src/adapter.ts
  var MAX_DOM_POSTS = 500;
  var articleSelector = 'article[data-testid="tweet"]';
  var primarySelector = '[data-testid="primaryColumn"]';
  function isHome(url) {
    return url.pathname.replace(/\/$/, "") === "/home";
  }
  function timelineKind(doc) {
    const tabs = [...doc.querySelector(primarySelector)?.querySelector('[role="tablist"]')?.querySelectorAll('[role="tab"]') ?? []];
    const index = tabs.findIndex((tab) => tab.getAttribute("aria-selected") === "true");
    const text = tabs[index]?.textContent?.replace(/\s+/g, " ").trim();
    return text ? `${index}:${text}` : null;
  }
  function timelineRoot(doc) {
    const primary = doc.querySelector(primarySelector);
    if (!primary) return null;
    for (const region of primary.querySelectorAll("[aria-label]")) {
      const label = region.getAttribute("aria-label") ?? "";
      if (/^(Timeline:|タイムライン[:：])/.test(label)) return region;
    }
    return null;
  }
  function timelineViewportTop(root, win) {
    const primary = root.closest(primarySelector);
    let top = 0;
    for (let node = primary?.querySelector('[role="tablist"]') ?? null; node && primary?.contains(node); node = node.parentElement) {
      const position = win.getComputedStyle(node).position;
      const rect = node.getBoundingClientRect();
      if ((position === "sticky" || position === "fixed") && rect.top <= 1 && rect.bottom > 0) top = Math.max(top, rect.bottom);
    }
    return top;
  }
  var excludedContent = '[data-testid="quoteTweet"], [data-testid="card.wrapper"], [data-testid="tweetText"]';
  function insideExcludedContent(element, article, timestamp) {
    for (let node = element; node && node !== article; node = node.parentElement) {
      if (node.matches(excludedContent) || node.matches('[role="link"]') && node !== timestamp) return true;
    }
    return element.closest(articleSelector) !== article;
  }
  function timestampStatusLinks(scope2, article) {
    const links = [];
    for (const time of scope2.querySelectorAll("time")) {
      const link = time.closest("a[href]");
      if (insideExcludedContent(time, article, link ?? void 0)) continue;
      if (!link || !scope2.contains(link)) continue;
      let url;
      try {
        url = new URL(link.getAttribute("href") ?? "", "https://x.com");
      } catch {
        continue;
      }
      if (url.hostname !== "x.com" || url.protocol !== "https:") continue;
      const match = url.pathname.match(/^\/[^/]+\/status\/(\d{1,30})(?:\/)?$/);
      if (match) links.push({ id: match[1], url });
    }
    return links;
  }
  function postId(article) {
    const header = [...article.querySelectorAll('[data-testid="User-Name"]')].find((el) => !insideExcludedContent(el, article));
    if (!header) return null;
    const ids = new Set(timestampStatusLinks(header, article).map((link) => link.id));
    return ids.size === 1 ? [...ids][0] : null;
  }
  function repostTarget(target) {
    if (!(target instanceof Element)) return null;
    const button = target.closest('button[data-testid="retweet"], button[data-testid="unretweet"]');
    if (!button || button.hasAttribute("disabled") || button.getAttribute("aria-disabled") === "true") return null;
    const article = button.closest(articleSelector);
    if (!article || insideExcludedContent(button, article) || article.parentElement?.closest(`${articleSelector}, ${excludedContent}, [role="link"]`)) return null;
    const headers = [...article.querySelectorAll('[data-testid="User-Name"]')].filter((header) => !insideExcludedContent(header, article));
    if (headers.length !== 1) return null;
    const urls = new Set(timestampStatusLinks(article, article).filter(({ url }) => url.origin === "https://x.com" && !url.username && !url.password).map(({ url }) => `https://x.com${url.pathname.replace(/\/$/, "")}/quotes`));
    if (urls.size !== 1) return null;
    return { button, article, url: [...urls][0] };
  }
  function readPosts(root) {
    const elements = [...root.querySelectorAll(articleSelector)].filter((el) => !el.parentElement?.closest(articleSelector));
    const posts = [];
    const boxes = [];
    for (const element of elements.slice(0, MAX_DOM_POSTS)) {
      const id = postId(element);
      const rect = element.getBoundingClientRect();
      if (rect.height <= 0) continue;
      const box = { element, top: rect.top, bottom: rect.bottom };
      boxes.push(box);
      if (id !== null) posts.push({ ...box, id });
    }
    return { posts, boxes, overLimit: elements.length > MAX_DOM_POSTS };
  }
  function parseRefreshLabel(label) {
    const normalized = label.normalize("NFKC").replace(/\s+/g, " ").trim();
    const english = normalized.match(/^Show (?:(\d+(?:,\d{3})*) (?:new )?|new )(?:posts?|Tweets?)$/i);
    const compact = normalized.replace(/\s/g, "");
    const japanese = compact.match(/^(?:(\d+(?:,\d{3})*)件の(?:新しい|新着)?|新しい|新着)(?:ポスト|ツイート)を表示$/) ?? compact.match(/^(?:新しい|新着)(?:ポスト|ツイート)を(\d+(?:,\d{3})*)件表示$/);
    const match = english ?? japanese;
    if (!match) return null;
    if (!match[1]) return {};
    const displayedCount = Number(match[1].replace(/,/g, ""));
    return Number.isSafeInteger(displayedCount) && displayedCount > 0 ? { displayedCount } : {};
  }
  function refreshDetails(target) {
    if (!(target instanceof Element)) return null;
    const control = target.closest('a, button, [role="button"], [role="tab"]');
    if (!control) return null;
    return parseRefreshLabel(control.textContent ?? "") ?? parseRefreshLabel(control.getAttribute("aria-label") ?? "");
  }
  function countedRefreshDetails(target, doc) {
    if (!(target instanceof Element)) return null;
    const control = target.closest('a, button, [role="button"], [role="tab"]');
    if (!control || !doc.querySelector(primarySelector)?.contains(control) || control.closest(`article, ${excludedContent}`)) return null;
    return refreshDetails(control);
  }
  function clickIntent(target) {
    if (!(target instanceof Element)) return null;
    const control = target.closest('a, button, [role="button"], [role="tab"]');
    if (!control) return null;
    if (refreshDetails(target)) return "refresh";
    return "navigate";
  }

  // src/refresh-paint-guard.ts
  var RefreshPaintGuard = class {
    constructor(doc, win, check, active) {
      this.doc = doc;
      this.win = win;
      this.check = check;
      this.active = active;
    }
    doc;
    win;
    check;
    active;
    frame = 0;
    host = null;
    cover = null;
    observer = null;
    start(root, viewportTop) {
      if (this.host) return;
      this.stop();
      this.cover = this.snapshot(root, viewportTop);
      const host = this.doc.createElement("div");
      host.setAttribute("aria-hidden", "true");
      host.style.cssText = "all:initial!important;position:fixed!important;left:0!important;top:0!important;width:1px!important;height:1px!important;overflow:hidden!important;visibility:hidden!important;pointer-events:none!important;contain:strict!important;";
      const probe = this.doc.createElement("div");
      probe.style.cssText = "width:1px;height:1px";
      host.attachShadow({ mode: "closed" }).append(probe);
      this.host = host;
      this.doc.documentElement.append(host);
      this.observer = new ResizeObserver(() => {
        this.check();
        if (!this.active()) this.finish();
      });
      this.observer.observe(probe);
      let width = 1;
      const pulse = () => {
        if (!this.active()) {
          this.finish();
          return;
        }
        probe.style.width = `${width = 3 - width}px`;
        this.frame = this.win.requestAnimationFrame(pulse);
      };
      this.frame = this.win.requestAnimationFrame(pulse);
    }
    snapshot(root, viewportTop) {
      const rect = root.getBoundingClientRect();
      const top = Math.max(viewportTop, rect.top, 0);
      const bottom = Math.min(this.win.innerHeight, rect.bottom);
      if (rect.width <= 0 || bottom <= top) return null;
      const cover = this.doc.createElement("div");
      cover.id = "x-home-refresh-cover";
      cover.setAttribute("aria-hidden", "true");
      let background = "Canvas";
      for (let node = root; node; node = node.parentElement) {
        const color = this.win.getComputedStyle(node).backgroundColor;
        if (color && color !== "transparent" && color !== "rgba(0, 0, 0, 0)") {
          background = color;
          break;
        }
      }
      const style = this.win.getComputedStyle(root);
      cover.style.cssText = `all:initial!important;position:fixed!important;left:${rect.left}px!important;top:${top}px!important;width:${rect.width}px!important;height:${bottom - top}px!important;overflow:hidden!important;pointer-events:auto!important;z-index:2147483646!important;contain:strict!important;background:${background}!important;font:${style.font}!important;color:${style.color}!important;`;
      const copy = root.cloneNode(true);
      copy.inert = true;
      copy.removeAttribute("id");
      for (const node of copy.querySelectorAll("[id]")) node.removeAttribute("id");
      for (const node of copy.querySelectorAll("script, style, link, iframe, object, embed")) node.remove();
      copy.style.setProperty("position", "absolute", "important");
      copy.style.setProperty("top", `${rect.top - top}px`, "important");
      copy.style.setProperty("left", "0", "important");
      copy.style.setProperty("width", `${rect.width}px`, "important");
      copy.style.setProperty("margin", "0", "important");
      const sources = root.querySelectorAll("video, canvas");
      const targets = copy.querySelectorAll("video, canvas");
      sources.forEach((source, index) => {
        const box = source.getBoundingClientRect();
        const frame = this.doc.createElement("canvas");
        frame.className = source.className;
        frame.style.cssText = source.style.cssText;
        frame.width = Math.max(1, Math.ceil(box.width));
        frame.height = Math.max(1, Math.ceil(box.height));
        frame.style.width = `${box.width}px`;
        frame.style.height = `${box.height}px`;
        try {
          frame.getContext("2d")?.drawImage(source, 0, 0, frame.width, frame.height);
        } catch {
        }
        targets[index]?.replaceWith(frame);
      });
      cover.append(copy);
      this.doc.documentElement.append(cover);
      return cover;
    }
    finish() {
      if (!this.host) return;
      const cover = this.cover;
      this.cover = null;
      this.stop();
      this.cover = cover;
      this.frame = this.win.requestAnimationFrame(() => {
        this.frame = this.win.requestAnimationFrame(() => {
          this.cover?.remove();
          this.cover = null;
          this.frame = 0;
        });
      });
    }
    stop() {
      this.win.cancelAnimationFrame(this.frame);
      this.frame = 0;
      this.observer?.disconnect();
      this.observer = null;
      this.host?.remove();
      this.host = null;
      this.cover?.remove();
      this.cover = null;
    }
    contains(target) {
      return target instanceof Node && !!this.cover?.contains(target);
    }
    get running() {
      return this.host !== null;
    }
  };

  // src/refresh-total.ts
  var memoryKey = /* @__PURE__ */ Symbol.for("x-home-anchor.refresh-total");
  var RefreshTotal = class {
    constructor(doc) {
      this.doc = doc;
      this.memory = doc[memoryKey] ??= { total: 0n };
      this.host = doc.createElement("div");
      this.host.id = "x-home-new-post-total";
      this.host.setAttribute("role", "status");
      this.host.setAttribute("aria-live", "off");
      const shadow = this.host.attachShadow({ mode: "closed" });
      const style = doc.createElement("style");
      style.textContent = `
      :host {
        all: initial !important;
        position: fixed !important;
        top: 8px !important;
        left: 8px !important;
        z-index: 2147483647 !important;
        pointer-events: none !important;
        user-select: none !important;
        display: block !important;
        width: max-content !important;
        font: 0.8rem/1.4 system-ui, sans-serif !important;
      }
      :host([hidden]) { display: none !important; }
      span {
        display: block;
        padding: 2px 6px;
        border-radius: 3px;
        background: #303030;
        color: #f5f5f5;
        font: 0.8rem/1.4 system-ui, sans-serif;
        font-variant-numeric: tabular-nums;
        white-space: nowrap;
        pointer-events: none;
      }
    `;
      this.value = doc.createElement("span");
      shadow.append(style, this.value);
      this.render();
    }
    doc;
    memory;
    host;
    value;
    render() {
      const total = this.memory.total.toString();
      this.value.textContent = total;
      this.host.setAttribute("aria-label", `\u64CD\u4F5C\u3057\u305F\u65B0\u7740\u8868\u793A\u30DC\u30BF\u30F3\u306E\u4EF6\u6570\u306E\u7D2F\u8A08: ${total}`);
    }
    show(home) {
      this.host.hidden = !home;
      if (!this.host.isConnected) this.doc.documentElement.append(this.host);
    }
    activate(event, url) {
      if (!event.isTrusted || !isHome(url)) return;
      const count = countedRefreshDetails(event.target, this.doc)?.displayedCount;
      if (count === void 0) return;
      this.memory.total += BigInt(count);
      this.render();
      this.show(true);
    }
    dispose() {
      this.host.remove();
    }
  };

  // src/repost-hold.ts
  var REPOST_HOLD_MS = 600;
  var MOVE_TOLERANCE = 10;
  var RELEASE_CLICK_MS = 800;
  var RepostHold = class {
    pending = null;
    completed = null;
    timer = 0;
    poll = 0;
    releaseTimer = 0;
    disposed = false;
    listeners = new AbortController();
    observer;
    doc;
    win;
    navigate;
    constructor(doc, win, navigate) {
      this.doc = doc;
      this.win = win;
      this.navigate = navigate;
      this.observer = new MutationObserver((records) => {
        const press = this.pending;
        if (press && records.some((record) => [...record.removedNodes].some((node) => node === press.article || node.contains(press.button)))) this.cancel();
        this.reconcile();
      });
      const options = { signal: this.listeners.signal, capture: true };
      win.addEventListener("pointerdown", (event) => this.down(event), options);
      win.addEventListener("pointermove", (event) => this.move(event), options);
      win.addEventListener("pointerout", (event) => {
        const press = this.pending;
        if (press && event.pointerId === press.pointerId && !this.onButton(event.relatedTarget, press)) this.cancel();
      }, options);
      win.addEventListener("pointerup", (event) => this.up(event), options);
      win.addEventListener("pointercancel", (event) => {
        if (this.pending?.pointerId === event.pointerId) this.cancel();
        if (this.completed?.pointerId === event.pointerId) this.releaseCompleted();
      }, options);
      win.addEventListener("click", (event) => {
        const press = this.completed;
        if (!press || event.button !== 0 || event.detail === 0 || !this.onButton(event.target, press)) return;
        if ("pointerId" in event && event.pointerId !== press.pointerId) return;
        this.suppress(event);
        this.clearCompleted();
      }, options);
      win.addEventListener("contextmenu", (event) => {
        const press = this.pending ?? this.completed;
        if (press?.pointerType !== "touch" || !this.onButton(event.target, press)) return;
        if ("pointerType" in event && event.pointerType !== "touch") return;
        if ("pointerId" in event && event.pointerId !== press.pointerId) return;
        this.suppress(event);
      }, options);
      for (const type of ["scroll", "wheel", "popstate", "hashchange", "pagehide", "keydown"]) {
        win.addEventListener(type, () => this.cancel(), { ...options, passive: true });
      }
      win.addEventListener("blur", (event) => {
        if (event.target === win) this.cancel();
      }, options);
      doc.addEventListener("visibilitychange", () => {
        if (doc.hidden) this.cancel();
      }, options);
      const navigation = win.navigation;
      for (const type of ["navigate", "currententrychange"]) navigation?.addEventListener(type, () => this.cancel(), options);
    }
    onButton(target, press) {
      return target instanceof Node && press.button.contains(target);
    }
    inside(press) {
      const rect = press.button.getBoundingClientRect();
      return press.x >= rect.left && press.x < rect.right && press.y >= rect.top && press.y < rect.bottom && this.onButton(this.doc.elementFromPoint(press.x, press.y), press);
    }
    valid(press) {
      if (this.disposed || this.doc.hidden || this.win.location.href !== press.page || !press.button.isConnected || !press.article.isConnected) return false;
      const current = repostTarget(press.button);
      return current?.button === press.button && current.article === press.article && current.url === press.url && this.inside(press);
    }
    down(event) {
      this.cancel();
      this.clearCompleted();
      if (event.button !== 0 || event.buttons !== 1 || !event.isPrimary || !["mouse", "touch"].includes(event.pointerType) || event.ctrlKey || event.metaKey || event.altKey || event.shiftKey || this.doc.hidden) return;
      const target = repostTarget(event.target);
      if (!target) return;
      const press = {
        ...target,
        pointerId: event.pointerId,
        pointerType: event.pointerType,
        x: event.clientX,
        y: event.clientY,
        startX: event.clientX,
        startY: event.clientY,
        page: this.win.location.href
      };
      if (!this.valid(press)) return;
      this.pending = press;
      this.observer.observe(this.doc.body, {
        subtree: true,
        childList: true,
        attributes: true,
        attributeFilter: ["href", "data-testid", "role", "disabled", "aria-disabled"]
      });
      this.poll = this.win.setInterval(() => this.reconcile(), 50);
      this.timer = this.win.setTimeout(() => {
        const current = this.pending;
        if (!current) return;
        const valid = this.valid(current);
        this.cancel();
        if (!valid) return;
        this.completed = current;
        this.navigate(current);
      }, REPOST_HOLD_MS);
    }
    move(event) {
      const press = this.pending;
      if (!press || event.pointerId !== press.pointerId) return;
      press.x = event.clientX;
      press.y = event.clientY;
      if (Math.hypot(press.x - press.startX, press.y - press.startY) > MOVE_TOLERANCE || event.buttons !== 1 || !this.valid(press)) this.cancel();
    }
    up(event) {
      if (this.pending?.pointerId === event.pointerId) this.cancel();
      if (this.completed?.pointerId !== event.pointerId || event.button !== 0) return;
      this.suppress(event);
      this.releaseCompleted();
    }
    suppress(event) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
    releaseCompleted() {
      this.win.clearTimeout(this.releaseTimer);
      this.releaseTimer = this.win.setTimeout(() => this.clearCompleted(), RELEASE_CLICK_MS);
    }
    clearCompleted() {
      this.win.clearTimeout(this.releaseTimer);
      this.releaseTimer = 0;
      this.completed = null;
    }
    cancel() {
      this.win.clearTimeout(this.timer);
      this.win.clearInterval(this.poll);
      this.timer = 0;
      this.poll = 0;
      this.pending = null;
      this.observer.disconnect();
    }
    reconcile() {
      if (this.pending && !this.valid(this.pending)) this.cancel();
    }
    dispose() {
      this.disposed = true;
      this.cancel();
      this.clearCompleted();
      this.listeners.abort();
    }
  };

  // src/quote-navigation.ts
  function openQuotes(target, signal) {
    const { article, url } = target;
    const doc = article.ownerDocument;
    const win = doc.defaultView;
    const more = [...article.querySelectorAll('button[data-testid="caret"]')].find((button) => button.closest('article[data-testid="tweet"]') === article && !button.closest('[data-testid="quoteTweet"], [data-testid="card.wrapper"], [data-testid="tweetText"]'));
    if (!win || signal.aborted) return;
    const page = win.location.href;
    const isCurrent = () => {
      const current = repostTarget(target.button);
      return !signal.aborted && !doc.hidden && article.isConnected && win.location.href === page && current?.article === article && current.url === url;
    };
    const listeners = new AbortController();
    let finished = false;
    let activated = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      observer.disconnect();
      win.clearTimeout(timer);
      listeners.abort();
    };
    const fallback = () => {
      if (finished) return;
      const navigate = isCurrent();
      finish();
      if (navigate) win.location.assign(url);
    };
    const check = () => {
      if (finished) return;
      if (!isCurrent()) {
        finish();
        return;
      }
      if (activated) return;
      const link = [...doc.querySelectorAll('[role="menu"] a[role="menuitem"][href]')].find((link2) => link2.href === url);
      if (link) {
        activated = true;
        link.click();
      }
    };
    const observer = new MutationObserver(check);
    const timer = win.setTimeout(fallback, 1e3);
    const cancel = () => finish();
    const options = { signal: listeners.signal, capture: true, passive: true };
    for (const type of ["pointerdown", "pointercancel", "wheel", "scroll", "keydown", "popstate", "pagehide"]) win.addEventListener(type, cancel, options);
    win.addEventListener("blur", (event) => {
      if (event.target === win) cancel();
    }, options);
    doc.addEventListener("visibilitychange", () => {
      if (doc.hidden) cancel();
    }, options);
    signal.addEventListener("abort", cancel, options);
    const navigation = win.navigation;
    for (const type of ["navigate", "currententrychange"]) navigation?.addEventListener(type, cancel, options);
    observer.observe(doc.body, { subtree: true, childList: true, attributes: true, attributeFilter: ["href", "role"] });
    check();
    if (!finished && !activated) {
      if (more) {
        more.click();
        check();
      } else fallback();
    }
  }

  // src/position.ts
  var CORRECTION_MS = 1800;
  var INPUT_QUIET_MS = 700;
  function chooseAnchors(posts, viewportHeight, viewportTop = 80) {
    const counts = /* @__PURE__ */ new Map();
    for (const post of posts) counts.set(post.id, (counts.get(post.id) ?? 0) + 1);
    const visible = posts.filter((p) => p.bottom > viewportTop && p.top < viewportHeight && counts.get(p.id) === 1);
    const first = visible.find((p) => p.top >= viewportTop) ?? visible[0];
    if (!first) return [];
    const index = posts.indexOf(first);
    return [first, ...[...posts.slice(index + 1, index + 5), ...posts.slice(Math.max(0, index - 2), index).reverse()].filter((p) => counts.get(p.id) === 1)].slice(0, 7).map((p) => ({ id: p.id, top: p.top }));
  }
  function resolveAnchor(anchors, posts) {
    for (const anchor of anchors) {
      const matches = posts.filter((p) => p.id === anchor.id);
      if (matches.length === 1) return { delta: matches[0].top - anchor.top };
    }
    return null;
  }
  var REFRESH_WAIT_MS = 3e3;
  var REFRESH_MAX_MS = 5e3;
  var REFRESH_SETTLE_MS = 1e3;
  var APPROXIMATE_WAIT_MS = 650;
  function median(values) {
    if (!values.length) return void 0;
    const sorted = [...values].sort((a, b) => a - b);
    const middle = Math.floor(sorted.length / 2);
    return (sorted[middle] + sorted[Math.floor((sorted.length - 1) / 2)]) / 2;
  }
  function representativeHeight(boxes, viewportHeight) {
    const local = boxes.map((box, index) => ({ box, index })).sort((a, b) => Math.abs(a.box.top - viewportHeight / 2) - Math.abs(b.box.top - viewportHeight / 2)).slice(0, 9).sort((a, b) => a.index - b.index);
    const height = median(local.map(({ box }) => box.bottom - box.top).filter((n) => n > 0));
    if (height === void 0 || local.length < 3) return void 0;
    const pitches = local.slice(1).map(({ box, index }, i) => index === local[i].index + 1 ? box.top - local[i].box.top : 0).filter((n) => n > 0 && n <= height * 3);
    return pitches.length >= 2 ? median(pitches) : height;
  }
  var PositionKeeper = class {
    anchors = [];
    until = 0;
    quietUntil = 0;
    needsIdle = false;
    retired = false;
    retireUntil = 0;
    refreshStart = null;
    lastActivity = 0;
    sawUpdate = false;
    missing = false;
    knownY;
    measurement = null;
    precisionRestored = false;
    approximationUsed = false;
    geometryAvailable = false;
    win;
    constructor(win) {
      this.win = win;
      this.knownY = win.scrollY;
    }
    get refreshing() {
      return this.refreshStart !== null;
    }
    get remainingMs() {
      let end = this.completionDeadline();
      const fallbackAt = this.approximationAt();
      if (this.geometryAvailable && fallbackAt !== null) end = Math.min(end, fallbackAt);
      return Math.max(0, end - performance.now());
    }
    get correcting() {
      return this.until > performance.now();
    }
    capture(posts) {
      if (this.until || this.retired || this.needsIdle || performance.now() < this.quietUntil) return;
      this.anchors = chooseAnchors(posts, this.win.innerHeight);
      this.knownY = this.win.scrollY;
    }
    interrupt() {
      if (this.refreshing) {
        this.retired = true;
        this.retireUntil = this.until;
      }
      this.until = 0;
      this.refreshStart = null;
      this.anchors = [];
      this.missing = false;
      this.measurement = null;
      this.knownY = this.win.scrollY;
      this.quietUntil = performance.now() + INPUT_QUIET_MS;
      this.needsIdle = true;
    }
    input() {
      if (this.retired && performance.now() >= this.retireUntil) this.retired = false;
      this.interrupt();
    }
    refresh(posts, context) {
      this.until = 0;
      this.refreshStart = null;
      this.anchors = [];
      this.retired = false;
      this.needsIdle = false;
      this.quietUntil = 0;
      this.capture(posts);
      const boxes = context?.boxes ?? posts;
      this.geometryAvailable = boxes.length > 0;
      if (!this.anchors.length && !boxes.length) {
        this.measurement = null;
        return;
      }
      const displayedCount = context?.displayedCount;
      const boundary = context?.boundary;
      this.measurement = {
        y: this.win.scrollY,
        boxes: boxes.map((box) => ({ element: box.element, y: box.top + this.win.scrollY })),
        ids: posts.map((post) => post.id),
        documentHeight: this.win.document.documentElement.scrollHeight,
        initialDocumentHeight: this.win.document.documentElement.scrollHeight,
        boundary: boundary && posts.filter((post) => post.id === boundary.id).length === 1 ? { ...boundary, knownIds: new Set(posts.map((post) => post.id)) } : void 0,
        representativeHeight: representativeHeight(boxes, this.win.innerHeight),
        ...displayedCount !== void 0 && displayedCount > 0 && Number.isSafeInteger(displayedCount) ? { displayedCount } : {}
      };
      this.refreshStart = performance.now();
      this.until = this.refreshStart + REFRESH_MAX_MS;
      this.lastActivity = this.refreshStart;
      this.sawUpdate = false;
      this.missing = false;
      this.precisionRestored = false;
      this.approximationUsed = false;
    }
    completionDeadline() {
      if (this.refreshStart === null) return this.until;
      if (!this.precisionRestored && this.approximationTarget()) return this.until;
      if (!this.sawUpdate) return this.refreshStart + REFRESH_WAIT_MS;
      return this.missing ? this.until : Math.min(this.until, Math.max(this.refreshStart + REFRESH_WAIT_MS, this.lastActivity + REFRESH_SETTLE_MS));
    }
    checkDeadline() {
      if (!this.until || performance.now() < this.completionDeadline()) return false;
      this.interrupt();
      return true;
    }
    acceptScroll() {
      const y = this.win.scrollY;
      if (Math.abs(y - this.knownY) < 1) return true;
      if (this.refreshing) {
        this.lastActivity = performance.now();
        return true;
      }
      this.interrupt();
      return false;
    }
    measureUpdate(posts, boxes) {
      const baseline = this.measurement;
      if (!baseline || !boxes.length) return;
      const before = new Set(baseline.boxes.map((box) => box.element));
      const first = baseline.boxes[0];
      const firstIndex = boxes.findIndex((box) => box.element === first?.element);
      let addedHeight;
      if (firstIndex >= 0) {
        const added = boxes[firstIndex].top + this.win.scrollY - first.y;
        const prefixInserted = firstIndex > 0 && boxes.slice(0, firstIndex).some((box) => !before.has(box.element));
        const commonShift = baseline.boxes.slice(0, 3).filter((old) => boxes.some((box) => box.element === old.element && Math.abs(box.top + this.win.scrollY - old.y - added) <= 1)).length >= 3;
        if (added > 1 && (prefixInserted || commonShift)) addedHeight = (baseline.restoredY ?? baseline.y) - baseline.y + added;
      }
      const newNodes = boxes.some((box) => !before.has(box.element));
      const newIds = posts.some((post) => !baseline.ids.includes(post.id));
      const upperPlacementChanged = first && boxes[0].top + this.win.scrollY > first.y + 1;
      const sameKnownIds = baseline.ids.length > 0 && posts.length === baseline.ids.length && posts.every((post, i) => post.id === baseline.ids[i]);
      if (this.precisionRestored) {
        const resetOnly = Math.abs((baseline.restoredY ?? baseline.y) - baseline.y) < 1;
        const documentGrew = this.win.document.documentElement.scrollHeight > baseline.documentHeight + 1;
        const replacement = !sameKnownIds && ((newNodes || newIds) && documentGrew || newNodes && resetOnly && (newIds || upperPlacementChanged));
        if (addedHeight === void 0 && !replacement) return;
        this.precisionRestored = false;
        baseline.addedHeight = addedHeight;
        baseline.updateAt = performance.now();
        this.sawUpdate = true;
        this.lastActivity = baseline.updateAt;
        return;
      }
      if (addedHeight !== void 0) baseline.addedHeight = addedHeight;
      if ((baseline.addedHeight !== void 0 || newIds || newNodes && upperPlacementChanged && !sameKnownIds) && baseline.updateAt === void 0) {
        baseline.updateAt = performance.now();
        this.sawUpdate = true;
        this.lastActivity = baseline.updateAt;
      }
    }
    revealUnread(posts, boxes) {
      const measurement = this.measurement;
      if (!measurement?.boundary || measurement.updateAt === void 0) return;
      const boundary = measurement.boundary;
      const index = posts.findIndex((post) => post.id === boundary.id);
      const next = posts[index - 1];
      const boxIndex = boxes.findIndex((box) => box.element === posts[index]?.element);
      if (!next || boundary.knownIds.has(next.id) || boxes[boxIndex - 1]?.element !== next.element || posts.filter((post) => post.id === boundary.id).length !== 1 || posts.filter((post) => post.id === next.id).length !== 1) return;
      const shift = next.top - boundary.top;
      this.anchors = chooseAnchors(posts.map((post) => ({ ...post, top: post.top - shift, bottom: post.bottom - shift })), this.win.innerHeight, boundary.top);
      measurement.boundary = void 0;
      this.approximationUsed = true;
    }
    rememberRestoration(posts, boxes, sampledY) {
      const baseline = this.measurement;
      if (!baseline) return;
      this.precisionRestored = true;
      baseline.boxes = boxes.map((box) => ({ element: box.element, y: box.top + sampledY }));
      baseline.ids = posts.map((post) => post.id);
      baseline.documentHeight = this.win.document.documentElement.scrollHeight;
      baseline.restoredY = this.win.scrollY;
    }
    approximationTarget() {
      const m = this.measurement;
      if (!m || this.approximationUsed) return null;
      const growth = this.win.document.documentElement.scrollHeight - m.initialDocumentHeight;
      const addedHeight = m.addedHeight ?? (growth > 1 ? growth : void 0) ?? (m.displayedCount && m.representativeHeight ? m.displayedCount * m.representativeHeight : void 0);
      return addedHeight === void 0 ? null : { y: m.y + addedHeight, addedHeight, estimated: m.addedHeight === void 0 };
    }
    approximationAt() {
      if (this.refreshStart === null || this.precisionRestored || !this.approximationTarget()) return null;
      return this.measurement?.updateAt === void 0 ? this.refreshStart + REFRESH_WAIT_MS : this.measurement.updateAt + APPROXIMATE_WAIT_MS;
    }
    approximate() {
      const m = this.measurement;
      if (!m || !this.geometryAvailable || this.precisionRestored || this.approximationUsed || this.refreshStart === null) return;
      const readyAt = m.updateAt === void 0 ? this.refreshStart + REFRESH_WAIT_MS : m.updateAt + APPROXIMATE_WAIT_MS;
      if (performance.now() < readyAt) return;
      const target = this.approximationTarget();
      if (!target) {
        if (m.updateAt !== void 0 && this.missing) this.interrupt();
        return;
      }
      if (target.addedHeight > 5e4) {
        this.interrupt();
        return;
      }
      const maxY = Math.max(0, this.win.document.documentElement.scrollHeight - this.win.innerHeight);
      const plannedY = Math.max(0, Math.min(maxY, target.y));
      const before = this.win.scrollY;
      if (plannedY > before) this.win.scrollTo({ top: plannedY, behavior: "instant" });
      this.knownY = this.win.scrollY;
      this.approximationUsed = true;
      if (!this.anchors.length) this.interrupt();
    }
    changed(posts, context) {
      const boxes = context?.boxes ?? posts;
      const sampledY = this.win.scrollY;
      this.geometryAvailable = boxes.length > 0;
      if (this.checkDeadline() || !this.anchors.length && !this.refreshing || this.retired || performance.now() < this.quietUntil) return;
      const now = performance.now();
      if (this.refreshing) {
        this.measureUpdate(posts, boxes);
        this.revealUnread(posts, boxes);
      }
      const moved = this.knownY - this.win.scrollY;
      const match = resolveAnchor(this.anchors, posts);
      const target = !match ? this.approximationTarget() : null;
      const maxY = Math.max(0, this.win.document.documentElement.scrollHeight - this.win.innerHeight);
      const nativeTolerance = target?.estimated ? Math.min(target.addedHeight * 0.15, (this.measurement?.representativeHeight ?? 0) * 2) : 1;
      const alreadyAnchored = target && this.win.scrollY > 1 && Math.abs(this.win.scrollY - Math.min(maxY, target.y)) <= nativeTolerance;
      if (moved && (!match || Math.abs(match.delta) >= 1) && !alreadyAnchored && !this.acceptScroll()) return;
      this.knownY = this.win.scrollY;
      if (!match) {
        if (this.refreshing && this.anchors.length && !this.missing) {
          this.sawUpdate = true;
          this.lastActivity = now;
        }
        this.missing = true;
        if (this.refreshing) this.approximate();
        else this.interrupt();
        return;
      }
      if (this.refreshing && (this.missing || Math.abs(match.delta - moved) >= 1)) {
        this.sawUpdate = true;
        this.lastActivity = now;
      }
      this.missing = false;
      if (this.refreshing && Math.abs(moved) >= 1 && Math.abs(match.delta) < 1) this.rememberRestoration(posts, boxes, sampledY);
      if (!this.until && Math.abs(match.delta) < 1) {
        this.capture(posts);
        return;
      }
      if (!this.until) this.until = now + CORRECTION_MS;
      if (Math.abs(match.delta) > 5e4) {
        this.interrupt();
        return;
      }
      if (Math.abs(match.delta) >= 1) {
        const before = this.win.scrollY;
        this.win.scrollBy({ top: match.delta, behavior: "instant" });
        this.knownY = this.win.scrollY;
        const actual = this.win.scrollY - before;
        if (Math.abs(actual - match.delta) > 1) this.interrupt();
        else if (this.refreshing && Math.abs(actual) >= 1) this.rememberRestoration(posts, boxes, sampledY);
      }
      if (this.refreshing) this.approximate();
    }
    scrolled(read, context) {
      if (this.checkDeadline()) return;
      const fallbackAt = this.approximationAt();
      if (Math.abs(this.win.scrollY - this.knownY) < 1 && !(this.geometryAvailable && fallbackAt !== null && performance.now() >= fallbackAt)) return;
      if (this.refreshing) {
        const posts = read();
        this.changed(posts, context?.());
      } else this.interrupt();
    }
    tick(posts, context) {
      if (this.checkDeadline()) return;
      if (this.refreshing) this.changed(posts, context);
      if (performance.now() >= this.quietUntil) this.needsIdle = false;
      this.capture(posts);
    }
  };

  // src/controller.ts
  var HomeController = class {
    constructor(doc, win) {
      this.doc = doc;
      this.win = win;
      this.keeper = new PositionKeeper(win);
      this.paintGuard = new RefreshPaintGuard(doc, win, () => this.checkScroll(), () => this.keeper.refreshing);
      this.refreshTotal = new RefreshTotal(doc);
      this.repostHold = new RepostHold(doc, win, (target) => {
        this.keeper.interrupt();
        this.detach();
        openQuotes(target, this.lifecycle.signal);
      });
      this.rootObserver = new MutationObserver(() => {
        this.reconcile();
        this.flush();
      });
      this.resizeObserver = new ResizeObserver(() => {
        if (this.root && this.isCurrent()) this.flush();
      });
      this.pageObserver = new MutationObserver((records) => {
        if (this.root && !this.root.isConnected) {
          this.reconcile();
          return;
        }
        if (this.root?.isConnected && this.lastPath === win.location.pathname && records.every((r) => this.root.contains(r.target))) return;
        this.schedule();
      });
      this.pageObserver.observe(doc.body, { subtree: true, childList: true, attributes: true, attributeFilter: ["aria-selected", "aria-label"] });
      const signal = this.lifecycle.signal;
      win.addEventListener("pointerdown", (event) => {
        this.coveredPointer = null;
        if (!this.paintGuard.contains(event.target)) return;
        this.coveredPointer = event.pointerId;
        this.coveredClickUntil = performance.now() + 1e3;
        event.preventDefault();
        event.stopImmediatePropagation();
        this.keeper.input();
        this.paintGuard.stop();
        this.settle();
      }, { signal, capture: true });
      win.addEventListener("click", (event) => {
        if (this.coveredPointer === null || event.detail === 0 || performance.now() > this.coveredClickUntil || event instanceof PointerEvent && event.pointerId !== this.coveredPointer) return;
        this.coveredPointer = null;
        event.preventDefault();
        event.stopImmediatePropagation();
      }, { signal, capture: true });
      win.addEventListener("pointercancel", () => {
        this.coveredPointer = null;
      }, { signal, capture: true });
      win.addEventListener("click", (event) => this.refreshTotal.activate(event, new URL(win.location.href)), { signal, capture: true });
      win.addEventListener("popstate", () => this.reconcile(), { signal });
      doc.addEventListener("visibilitychange", () => {
        if (doc.hidden) this.keeper.interrupt();
        this.reconcile();
      }, { signal });
      this.poll = win.setInterval(() => {
        if (this.lastPath !== win.location.pathname || !this.root?.isConnected) this.reconcile();
      }, 500);
      this.reconcile();
    }
    doc;
    win;
    kind = null;
    root = null;
    keeper;
    paintGuard;
    refreshTotal;
    repostHold;
    state = "outside";
    overLimit = false;
    frame = 0;
    settleTimer = 0;
    expiryTimer = 0;
    poll = 0;
    disposed = false;
    coveredPointer = null;
    coveredClickUntil = 0;
    lifecycle = new AbortController();
    inputs = null;
    rootObserver;
    resizeObserver;
    pageObserver;
    measured = /* @__PURE__ */ new Set();
    lastPath = "";
    lastKind = null;
    isCurrent() {
      return isHome(new URL(this.win.location.href)) && timelineKind(this.doc) === this.kind && !this.doc.hidden;
    }
    currentSample() {
      if (!this.root?.isConnected || timelineRoot(this.doc) !== this.root) return null;
      return readPosts(this.root);
    }
    schedule() {
      if (this.frame || this.disposed) return;
      this.frame = this.win.requestAnimationFrame(() => {
        this.frame = 0;
        this.reconcile();
      });
    }
    detach(preservePaint = false) {
      this.rootObserver.disconnect();
      this.resizeObserver.disconnect();
      this.measured.clear();
      this.inputs?.abort();
      this.inputs = null;
      this.win.clearTimeout(this.settleTimer);
      this.win.clearTimeout(this.expiryTimer);
      this.root = null;
      if (!preservePaint) this.paintGuard.stop();
    }
    settle() {
      this.win.clearTimeout(this.settleTimer);
      this.settleTimer = this.win.setTimeout(() => {
        if (!this.root || !this.isCurrent()) return;
        const sample = this.currentSample();
        if (sample?.overLimit) {
          this.keeper.interrupt();
          this.paintGuard.stop();
          return;
        }
        if (!sample) this.keeper.changed([], { boxes: [] });
        this.keeper.tick(sample?.posts ?? [], { boxes: sample?.boxes ?? [] });
      }, INPUT_QUIET_MS + 100);
    }
    expireCorrection() {
      this.win.clearTimeout(this.expiryTimer);
      if (this.keeper.correcting) this.expiryTimer = this.win.setTimeout(() => {
        if (this.isCurrent()) {
          const sample = this.currentSample();
          if (sample?.overLimit) {
            this.keeper.interrupt();
            this.paintGuard.stop();
            return;
          }
          if (!sample) this.keeper.changed([], { boxes: [] });
          this.keeper.tick(sample?.posts ?? [], { boxes: sample?.boxes ?? [] });
          this.expireCorrection();
          this.settle();
        }
      }, this.keeper.remainingMs + 1);
    }
    attach(root) {
      this.root = root;
      this.rootObserver.observe(root, { subtree: true, childList: true, attributes: true, attributeFilter: ["href", "data-testid", "role"] });
      this.inputs = new AbortController();
      const signal = this.inputs.signal;
      const interrupt = () => {
        this.keeper.input();
        this.paintGuard.stop();
        this.settle();
      };
      for (const type of ["wheel", "touchstart", "touchmove", "pointerdown"]) this.win.addEventListener(type, interrupt, { signal, passive: true, capture: true });
      this.win.addEventListener("resize", interrupt, { signal, passive: true });
      this.win.addEventListener("keydown", (event) => {
        if (this.paintGuard.running || ["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End", " ", "j", "k"].includes(event.key)) interrupt();
      }, { signal, capture: true });
      this.win.addEventListener("click", (event) => {
        const intent = clickIntent(event.target);
        if (intent === "refresh" && event.isTrusted && this.root && this.isCurrent() && this.state === "active") {
          const sample = this.currentSample();
          if (!sample || sample.overLimit) {
            this.keeper.interrupt();
            this.paintGuard.stop();
            return;
          }
          const viewportTop = timelineViewportTop(this.root, this.win);
          const control = event.target instanceof Element ? event.target.closest('a, button, [role="button"], [role="tab"]') : null;
          const boundary = sample.posts.find((post) => post.top >= (control?.getBoundingClientRect().bottom ?? Infinity));
          this.keeper.refresh(sample.posts, { boxes: sample.boxes, ...refreshDetails(event.target), boundary: boundary ? { id: boundary.id, top: viewportTop } : void 0 });
          this.expireCorrection();
          if (this.keeper.refreshing) this.paintGuard.start(this.root, viewportTop);
        } else if (intent === "navigate") {
          this.keeper.interrupt();
          this.paintGuard.stop();
        }
        this.settle();
      }, { signal, capture: true });
      this.win.addEventListener("scroll", () => {
        this.checkScroll();
        this.settle();
      }, { signal, passive: true });
      this.flush();
    }
    checkScroll() {
      if (!this.isCurrent()) {
        this.keeper.interrupt();
        this.paintGuard.stop();
        return;
      }
      let sample = null;
      const current = () => {
        if (!sample && this.root) {
          sample = this.currentSample();
        }
        if (sample?.overLimit) {
          this.keeper.interrupt();
          return null;
        }
        return sample;
      };
      this.keeper.scrolled(() => current()?.posts ?? [], () => ({ boxes: current()?.boxes ?? [] }));
      if (!this.keeper.refreshing) this.paintGuard.finish();
    }
    reconcile() {
      if (this.disposed) return;
      this.repostHold.reconcile();
      this.lastPath = this.win.location.pathname;
      const home = isHome(new URL(this.win.location.href));
      this.refreshTotal.show(home);
      const kind = home ? timelineKind(this.doc) : null;
      const root = home ? timelineRoot(this.doc) : null;
      if (kind !== this.lastKind || !home) {
        this.keeper.interrupt();
        this.detach();
      }
      this.kind = kind;
      this.lastKind = kind;
      this.state = !home ? "outside" : !kind || !root || this.overLimit ? "unrecognized" : "active";
      const needsTimeline = home && kind && root && !this.doc.hidden;
      if (!needsTimeline) {
        if (home && kind && !root && !this.doc.hidden && this.keeper.refreshing) {
          this.rootObserver.disconnect();
          this.resizeObserver.disconnect();
          this.measured.clear();
          this.root = null;
          this.keeper.changed([], { boxes: [] });
          return;
        }
        this.keeper.interrupt();
        this.detach();
        this.overLimit = false;
        return;
      }
      if (root !== this.root) {
        this.detach(this.keeper.refreshing);
        this.attach(root);
        if (this.keeper.refreshing) this.paintGuard.start(root, timelineViewportTop(root, this.win));
      }
    }
    flush() {
      if (!this.root || !this.isCurrent()) return;
      const sample = this.currentSample();
      if (!sample) {
        this.keeper.changed([], { boxes: [] });
        return;
      }
      this.overLimit = sample.overLimit;
      this.state = sample.overLimit ? "unrecognized" : "active";
      const nodes = new Set(sample.boxes.map((p) => p.element));
      for (const element of this.measured) if (!nodes.has(element)) this.resizeObserver.unobserve(element);
      for (const element of nodes) if (!this.measured.has(element)) this.resizeObserver.observe(element);
      this.measured = nodes;
      if (this.state === "active") {
        this.keeper.changed(sample.posts, { boxes: sample.boxes });
        this.keeper.capture(sample.posts);
        this.expireCorrection();
      } else this.keeper.interrupt();
      this.settle();
    }
    status() {
      this.reconcile();
      return { state: this.state };
    }
    dispose() {
      this.repostHold.dispose();
      this.disposed = true;
      this.keeper.interrupt();
      this.detach();
      this.lifecycle.abort();
      this.pageObserver.disconnect();
      this.refreshTotal.dispose();
      this.win.cancelAnimationFrame(this.frame);
      this.win.clearInterval(this.poll);
    }
  };

  // src/content.ts
  var singleton = /* @__PURE__ */ Symbol.for("x-home-anchor.instance");
  var scope = globalThis;
  scope[singleton]?.();
  function install() {
    const controller = new HomeController(document, window);
    const onMessage = (message, sender, respond) => {
      if (sender.id !== chrome.runtime.id || typeof message !== "object" || message === null) return;
      const command = message.command;
      if (command === "status") respond(controller.status());
    };
    chrome.runtime.onMessage.addListener(onMessage);
    return () => {
      controller.dispose();
      chrome.runtime.onMessage.removeListener(onMessage);
    };
  }
  var uninstall = install();
  var onHide = () => uninstall();
  var onShow = (event) => {
    if (event.persisted) {
      uninstall();
      uninstall = install();
    }
  };
  window.addEventListener("pagehide", onHide);
  window.addEventListener("pageshow", onShow);
  scope[singleton] = () => {
    uninstall();
    window.removeEventListener("pagehide", onHide);
    window.removeEventListener("pageshow", onShow);
  };
})();
