"use strict";
(() => {
  // src/popup.ts
  var status = document.getElementById("status");
  var states = {
    active: "\u4F4D\u7F6E\u4FDD\u6301\u304C\u52D5\u4F5C\u4E2D\u3067\u3059\u3002",
    outside: "\u5BFE\u8C61\u5916\u306E\u753B\u9762\u3067\u3059\u3002",
    unrecognized: "\u753B\u9762\u69CB\u9020\u3092\u8A8D\u8B58\u3067\u304D\u307E\u305B\u3093\u3002"
  };
  async function initialize() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id === void 0) throw new Error("No active tab");
      const value = await chrome.tabs.sendMessage(tab.id, { command: "status" });
      status.textContent = states[value.state];
    } catch {
      status.textContent = "\u63A5\u7D9A\u3067\u304D\u307E\u305B\u3093\u3002";
    }
  }
  void initialize();
})();
